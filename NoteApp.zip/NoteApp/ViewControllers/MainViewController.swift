//
//  MainViewController.swift
//  Whats_App
//
//  Created by Ibrahim Alperen Kurum on 16.09.2025.
//

import UIKit

final class MainViewController: UIViewController, UIGestureRecognizerDelegate {
    
    private var notesTableView = UITableView(frame: .zero, style: .grouped)
    private var filteredNotes : [Note] = []
    private var notes : [Note] = []
    private let searchController = UISearchController()
    private var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let data = UserDefaults.standard.value(forKey: "notes") as? Data {
            do{
                notes = try PropertyListDecoder().decode([Note].self, from: data)       // TODO: - do/catch yap
            }catch {
                print("\nEror has occured at decoding. Error: \(error)")
            }
        }
        self.hideKeyboardWhenTappedAround()
        configureUI()
    }
 
    
    private func configureUI() {
        view.backgroundColor = .systemBackground
        configureNavigationBar()
        configureTableView()
        configureSearchController()
        configureRefreshControl()
    }
    
    private func configureNavigationBar() {
        navigationItem.title = "Notlar"
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewNote))
    }
    
    private func configureSearchController() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Başlık araması ..."
        searchController.searchBar.sizeToFit()
        searchController.searchBar.searchBarStyle = .prominent

        navigationItem.searchController = searchController
        
        definesPresentationContext = true
    }

    
    private func configureRefreshControl() {
        notesTableView.addSubview(refreshControl)
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }

    private func configureTableView() {
        view.addSubview(notesTableView)
        notesTableView.delegate = self
        notesTableView.dataSource = self
        notesTableView.register(NotesTableViewCell.self, forCellReuseIdentifier: "NoteCell")
        notesTableView.register(NotesFooterView.self, forHeaderFooterViewReuseIdentifier: NotesFooterView.reuseIdentifier)
        notesTableView.pin(to: view)
        notesTableView.tableFooterView = UIView()
        notesTableView.keyboardDismissMode = .onDrag
    }
    
    @objc private func refreshData() {
        notesTableView.reloadData()
        refreshControl.endRefreshing()
    }
    
    @objc private func addNewNote() {
        let newNoteVC = NewNoteViewController()
        //newNoteVC.delegateNote = self//retain cycle
        newNoteVC.newNote = { [weak self] note in
            self?.notes.append(note)
            self?.notesTableView.reloadData()
            self?.updateNotesInUserDefaults()
        }
        navigationController?.pushViewController(newNoteVC, animated: true)
    }
    
    private func filterContentForSearchText(_ searchText: String) {
        guard !searchText.isEmpty else {
            notesTableView.reloadData()
            return }
        filteredNotes = notes.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        notesTableView.reloadData()
    }
    
    var isFiltering: Bool {
        searchController.isActive && !searchController.searchBar.text!.isEmpty
    }
}

// MARK: - UISearchResultsUpdating
extension MainViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)
    }
}

// MARK: - UITableViewDelegate
extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        view.endEditing(true)
        let detailViewController = createNewNoteViewController(in: indexPath)
        navigationController?.pushViewController(detailViewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        guard let footer = tableView.dequeueReusableHeaderFooterView(
            withIdentifier: NotesFooterView.reuseIdentifier
        ) as? NotesFooterView else {
            return nil
        }
        let rowCount = tableView.numberOfRows(inSection: section)
        footer.configureNotesCount(noteCount: rowCount)
        return footer
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 14
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = deleteActionHandler(tableView, leadingSwipeActionsConfigurationForRowAt: indexPath)
        let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
        configuration.performsFirstActionWithFullSwipe = true
        return configuration
    }
    
    private func deleteActionHandler(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UIContextualAction{
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completionHandler) in
            self.notes.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.reloadData()
            self.updateNotesInUserDefaults()
            completionHandler(true)
        }
        deleteAction.backgroundColor = .red
        return deleteAction
    }
    
    private func createNewNoteViewController(in indexPath: IndexPath) -> NewNoteViewController {
        let selectedNote = notes[indexPath.row]
        let detailViewController = NewNoteViewController()
        detailViewController.bodyTextView.text = selectedNote.text
        detailViewController.titleTextField.text = selectedNote.title
        detailViewController.bodyTextView.isEditable = false
        detailViewController.titleTextField.isUserInteractionEnabled = false
        detailViewController.showEditOrSave = true
        detailViewController.noteIndexPath = indexPath
        detailViewController.updateNote = { [weak self] note, indexPath in
            self?.notes[indexPath.row] = note
            self?.notesTableView.reloadData()
            self?.updateNotesInUserDefaults()
        }
        //detailViewController.delegateNote = self
        return detailViewController
    }
}

extension MainViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering {
            return filteredNotes.count
        }
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NoteCell", for: indexPath) as! NotesTableViewCell
        let note = isFiltering ? filteredNotes[indexPath.row] : notes[indexPath.row]
        cell.set(note: note, index: indexPath.row)
        //weak tekrar bak
        //weake tekrardan baktim strong reference olanlarda weak kullanmaz isek reference edilen obje nil oldugunda strong bagli oldugu icin nill olmasina izin vermez ve obje deinit olamaz bu yuzden dolayi reference ederken weak reference yaparsak obje nilkl oldugunda reference da nil olabilir ve boylece obje deinit olabilir fakat burada oncheckdi main view controllerda weak self yapamamizin nedenini tam anlayamadim weak kalidirinca da sikintisiz tum fonksiyonlar calisiyor
        //for protocol
        cell.delegateOnChecked = self
        /*Call Back
         cell.onChecked = { [weak self] isChecked, index in
            if case self?.isFiltering = true{
                self?.filteredNotes[index].check = isChecked
                if let originalIndex = self?.notes.firstIndex(where: {$0.id == self?.filteredNotes[index].id}){
                    self?.notes[originalIndex].check = isChecked
                }
            }else{
                self?.notes[index].check = isChecked
            }
            self?.notesTableView.reloadData()
            self?.updateNotesInUserDefaults()
            print(isChecked)
            print(index)
        }*/
        return cell
    }
}

/* FOR PROTOCOL
 extension MainViewController: NoteDelegate {
    func didNoteAdd(note: Note) {
        notes.append(note)
        notesTableView.reloadData()
        updateNotesInUserDefaults()
    }
    
    func didNoteUpdate(note: Note, at indexPath: IndexPath) {
        notes[indexPath.row] = note
        notesTableView.reloadData()
        updateNotesInUserDefaults()
    }
}*/

extension MainViewController {
    func updateNotesInUserDefaults() {
        // TODO: - ?/! arasında ne fark var yukarıda ! kullanılmış burada ? kullanılmış
        //hata durumunda nil donmesinde sikinti olamyacagi icin optional kullanilmistir
        let obj = try? PropertyListEncoder().encode(notes)
        UserDefaults.standard.set(obj, forKey: "notes")
        //UserDefaults.standard.synchronize() // TODO: - before removing it, check
        //user defaults automaticly doing the changes
    }
}

extension MainViewController: OnCheckedDelegate {
    func onChecked(isChecked: Bool, index: Int) {
        if case isFiltering = true{
            filteredNotes[index].check = isChecked
            if let originalIndex = notes.firstIndex(where: {$0.id == filteredNotes[index].id}){
                notes[originalIndex].check = isChecked
            }
        }else{
            notes[index].check = isChecked
        }
        notesTableView.reloadData()
        updateNotesInUserDefaults()
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        navigationController?.view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
