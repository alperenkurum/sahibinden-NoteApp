//
//  Note.swift
//  Whats_App
//
//  Created by Ibrahim Alperen Kurum on 16.09.2025.
//
import UIKit

struct Note: Codable{
    var title: String
    var text: String
    var check: Bool = false
    let id: UUID = UUID()
}
